const { Client, GatewayIntentBits, Partials, ActivityType , Permissions } = require('discord.js');
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.User,
    Partials.GuildMember
  ]
});

const config = require("./config");
const prefix = config.prefix;
const errorChannelId = config.errorChannelId; // Error channel ID

const mafiaCommand = require("./wolfs");
const rouletteCommand = require("./roulette");
const { werewolf_command } = require('./actions/werewolfCommand');
const fs = require('fs');
const path = require('path');

const ownerId = '520774569855025152'; // Replace with your actual Discord user ID

// Function to update the configuration file
const updateConfig = (key, value) => {
  const configPath = path.resolve(__dirname, 'config.js');
  const config = require(configPath);
  config[key] = value;
  fs.writeFileSync(configPath, `module.exports = ${JSON.stringify(config, null, 2)};`);
};

// Function to send error messages to the error channel
const sendError = async (message) => {
  try {
    const errorChannel = await client.channels.fetch(errorChannelId);
    if (errorChannel) {
      await errorChannel.send(`Error occurred: ${message}`);
    }
  } catch (err) {
    console.error('Failed to send error message:', err);
  }
};

client.once("ready", () => {
  client.user.setPresence({ 
    activities: [{ 
        name: 'Eric Bots', 
        type: ActivityType.Streaming, 
        url: 'https://twitch.tv/.' 
    }], 
    status: 'dnd' 
});
  console.log(`Logged in as ${client.user.tag}`);
  console.log(`Total members: ${client.guilds.cache.reduce((size, g) => size + g.memberCount, 0)}`);
});

client.on('messageCreate', async message => {
  if (!message.guild || message.author.bot) return;

  try {
    // Handle setroles command
    if (message.content.startsWith(`${prefix}setrole`)) {
      if (message.author.id !== ownerId) return; // Check if the user ID matches

      const mentionedRoles = message.mentions.roles.map(role => role.id);
      if (mentionedRoles.length === 0) {
        return message.channel.send('Please mention at least one role.');
      }

      // Update the admin roles list
      config.admin_roles = mentionedRoles;
      updateConfig('admin_roles', mentionedRoles);

      message.channel.send('Admin roles updated.');
    }

    // Handle restart command
    if (message.content.startsWith(`${prefix}restart`)) {
      if (!message.member.roles.cache.hasAny(...config.admin_roles)) return;
      message.channel.send('Restarting bot...').then(() => {
        process.exit(); // Exiting process will restart if managed by PM2 or similar
      });
    }

    // Handle other commands
    const args = message.content.split(" ");
    if (args[0] === `${prefix}e`) {
      if (!message.member.roles.cache.hasAny(...config.admin_roles)) return;
      mafiaCommand(message); // Call the imported function
    } else if (args[0] === `${prefix}روليت`) {
      if (!message.member.roles.cache.hasAny(...config.admin_roles)) return;
      rouletteCommand(message); // Call the imported function
    } else if (args[0] === `${config.prefix}r`) {
      if (!message.member.roles.cache.hasAny(...config.admin_roles)) return;
      werewolf_command(message);
    }
  } catch (error) {
    console.error('Error handling message:', error);
    sendError(error.message);
  }
});

client.login(config.token);
