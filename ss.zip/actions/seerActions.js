const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function seer_actions(message, data) {
  let seer = data.players.find(p => p.type === "seer");
  if (!seer) return;

  let rows = [];
  let row = new ActionRowBuilder();

  data.players.forEach((player, index) => {
    if (player.id !== seer.id) { // Seer cannot reveal themselves
      let button = new ButtonBuilder()
        .setCustomId(`reveal_${player.id}`)
        .setLabel(player.username)
        .setStyle(ButtonStyle.Secondary);

      row.addComponents(button);

      if ((index + 1) % 5 === 0) {
        rows.push(row);
        row = new ActionRowBuilder();
      }
    }
  });

  if (row.components.length > 0) rows.push(row);

  let revealMessage = await seer.interaction.followUp({
    content: "🔮 Choose a player to reveal their role:",
    components: rows,
    ephemeral: true
  });

  let collector = revealMessage.createMessageComponentCollector({ time: 30000 });

  return new Promise(resolve => {
    collector.on('collect', async interaction => {
      if (!interaction.isButton()) return;

      let revealedPlayerId = interaction.customId.split('_')[1];
      let revealedPlayer = data.players.find(p => p.id === revealedPlayerId);

      await interaction.reply({
        content: `${revealedPlayer.username} is a ${revealedPlayer.type}.`,
        ephemeral: true
      });

      resolve(revealedPlayerId);
    });

    collector.on('end', () => {
      resolve(null);
    });
  });
}

module.exports = seer_actions;
