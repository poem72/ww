const { ButtonStyle, ButtonBuilder, EmbedBuilder, ActionRowBuilder, AttachmentBuilder } = require("discord.js");
const config = require("./config");
const has_play = new Map();

async function mafia_command(message) {
  if (has_play.get(message.guild.id)) return message.reply({ content: `❌ هناك بالفعل لعبة فعالة في هذا السيرفر!` });
  let time = 30000;
  let data = {
    author: message.author.id,
    players: [],
    start_in: Date.now() + time,
    type: "werewolf"
  }
  const mention = '@everyone';
  const attachment = new AttachmentBuilder('./s2.png');

  const embed = new EmbedBuilder()
    .setColor("#1c2935")
    .setTitle("Werewolf")
    .setDescription(`__ستبدأ اللعبة خلال__: **<t:${Math.floor(data.start_in / 1000)}:R>**`);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('join_werewolf')
        .setLabel('دخول'),
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('left_werewolf')
        .setLabel('خروج')
    );

  let msg = await message.channel.send({
    content: mention,
    files: [attachment],
    components: [row]
  });

  has_play.set(message.guild.id, data);

  let start_c = msg.createMessageComponentCollector({ time: time });
  start_c.on("collect", async inter => {
    if (!has_play.get(message.guild.id)) return;
    if (inter.customId === "join_werewolf") {
      if (data.players.find(u => u.id == inter.user.id)) return inter.reply({ content: `لقد سجلت بالفعل.`, ephemeral: true });
      if (data.players.length >= 20) return inter.reply({ content: `عدد المشاركين مكتمل`, ephemeral: true });
      data.players.push({
        id: inter.user.id,
        username: inter.user.username,
        avatar: inter.user.displayAvatarURL({ dynamic: true, format: "png" }),
        type: "villager",
        interaction: inter,
        vote_kill: 0,
        vote_kick: 0
      });
      has_play.set(message.guild.id, data);
      embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__اللاعبين المشاركين:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
      msg.edit({ embeds: [embed] }).catch(() => 0);
      inter.reply({ content: `✅ تم إضافتك للمشتركين بنجاح`, ephemeral: true });
    } else if (inter.customId == "left_werewolf") {
      let index = data.players.findIndex(i => i.id == inter.user.id);
      if (index == -1) return inter.reply({ content: `❌ - انت غير مشارك بالفعل`, ephemeral: true });
      data.players.splice(index, 1);
      has_play.set(message.guild.id, data);
      embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__اللاعبين المشاركين:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
      msg.edit({ embeds: [embed] }).catch(() => 0);
      inter.reply({ content: `✅ تم إزالتك من المشتركين`, ephemeral: true });
    }
  });
  start_c.on("end", async (end, reason) => {
    if (!has_play.get(message.guild.id)) return;
    embed.setDescription(`*(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`)
      .setColor("Red");
    msg.edit({ embeds: [embed], components: [row_2] }).catch(() => 0);
    if (data.players.length < 1) {
      has_play.delete(message.guild.id);
      return message.channel.send({ content: `🚫 - تم إلغاء اللعبة لعدم وجود 5 لاعبين على الأقل` });
    }
    let c = 5;
    for (let i = 0; i < data.players.length; i += c) {
      let array = data.players.slice(i, i + c);
      if (i == 0) {
        let werewolf_i = Math.floor(Math.random() * array.length);
        let werewolf = array[werewolf_i];
        array.splice(werewolf_i, 1);
        let werewolf_index = data.players.findIndex(m => m.id == werewolf.id);
        if (werewolf_index != -1) {
          data.players[werewolf_index].type = "werewolf";
        }
        let seer_i = Math.floor(Math.random() * array.length);
        let seer = array[seer_i];
        let seer_index = data.players.findIndex(m => m.id == seer.id);
        data.players[seer_index].type = "seer";
        let doctor_i = Math.floor(Math.random() * array.length);
        let doctor = array[doctor_i];
        let doctor_index = data.players.findIndex(m => m.id == doctor.id);
        data.players[doctor_index].type = "doctor";
      } else {
        if (array.length >= 5) {
          let werewolf_i = Math.floor(Math.random() * array.length);
          let werewolf = array[werewolf_i];
          let werewolf_index = data.players.findIndex(m => m.id == werewolf.id);
          if (werewolf_index != -1) {
            data.players[werewolf_index].type = "werewolf";
          } 
        }
      }
    }
    has_play.set(message.guild.id, data);
    for (let player of data.players) {
      if (player.type == "villager") {
        await player.interaction.followUp({ content: `👥 | تم اختيارك انت كـ **مواطن**. في كل جولة يجب عليك التحقق مع جميع اللاعبين لأكتشاف الذئاب وطردهم من اللعبة`, ephemeral: true }).catch(() => 0);
      } else if (player.type == "doctor") {
        await player.interaction.followUp({ content: `🧑‍⚕️ | تم اختيارك انت كـ **الطبيب**. في كل جولة يمكنك حماية شخص واحد من هجوم الذئاب`, ephemeral: true }).catch(() => 0);
      } else if (player.type == "werewolf") {
        await player.interaction.followUp({ content: `🕵️ | تم اختيارك انت  كـ **ذئب**. يجب عليكم محاولة اغتيال جميع اللاعبين بدون اكتشافكم`, ephemeral: true }).catch(() => 0);
      } else if (player.type == "seer") {
        await player.interaction.followUp({ content: `🔮 | تم اختيارك انت كـ **العراف**. يمكنك التحقق من أحد اللاعبين في كل جولة لمعرفة إذا كان ذئب`, ephemeral: true }).catch(() => 0);
    }    
    }
    message.channel.send({
      content: `
✅ تم توزيع الرتب على اللاعبين. ستبدأ الجولة الأولى في بضع ثواني...

__الفريق الأول (المواطنين):__
**${data.players.filter(p => p.type == "doctor").length}** طبيب
**${data.players.filter(p => p.type == "villager").length}** مواطن

__الفريق الثاني (الذئاب):__
**${data.players.filter(p => p.type == "werewolf").length}** ذئب
`
    });
    await sleep(700);
    await werewolf_game(message);
  });
}

async function werewolf_game(message) {
  if (!message || !message.guild) return;
  let data = has_play.get(message.guild.id);
  if (!data) return;
  let werewolves = data.players.filter(t => t.type == "werewolf");
  let doctor = data.players.find(t => t.type == "doctor");
  let villagers = data.players.filter(t => t.type != "werewolf");
  let seer = data.players.find(t => t.type == "seer");
  let villager_buttons = createMultipleButtons(villagers.map((p) => ({ id: p.id, label: p.username, disabled: false, index: villagers.findIndex(u => u.id == p.id) })), "kill");
  for (let w of werewolves) {
    await w.interaction.followUp({ content: `أمامك 20 ثانية للتصويت على مواطن ليتم قتله`, components: villager_buttons, ephemeral: true }).catch(() => 0);
  }
  message.channel.send({ content: `🔪 | جاري انتظار الذئاب لاختيار شخص لقتله...` });
  let kill_c = message.channel.createMessageComponentCollector({ filter: w => werewolves.find(n => n.id == w.user.id) && w.customId.startsWith("kill"), time: 20000 });
  let collected = [];
  kill_c.on("collect", async inter => {
    if (!has_play.get(message.guild.id)) return;
    if (collected.find(i => i == inter.user.id)) return;
    collected.push(inter.user.id);
    await inter.update({ content: `تم التصويت بنجاح انتظر النتيجة`, components: [] }).catch(() => 0);
    let villager_index = villagers.findIndex(i => i.id == inter.customId.split("_")[1]);
    if (villager_index != -1) {
      let villager = villagers[villager_index];
      let player_index = data.players.findIndex(p => p.id == villager.id);
      if (player_index != -1) {
        data.players[player_index].vote_kill++;
      }
    }
    if (collected.length == werewolves.length) return kill_c.stop();
  });
  kill_c.on("end", async end => {
    if (!has_play.get(message.guild.id)) return;
    let villager_index = villagers.map(i => i.vote_kill).indexOf(Math.max(...villagers.map(i => i.vote_kill)));
    let player = villagers[villager_index];
    let player_index = data.players.findIndex(p => p.id == player.id);
    if (doctor) {
      let buttons = createMultipleButtons(villagers.map((p) => ({ id: p.id, label: p.username, disabled: false, index: villagers.findIndex(u => u.id == p.id) })), "save");
      await doctor.interaction.followUp({ content: `امامك 20 ثانية للتصويت على شخص لحمايته`, components: buttons, ephemeral: true }).catch(() => 0);
      let save_c = message.channel.createMessageComponentCollector({ filter: i => i.user.id == doctor.id && i.customId.startsWith("save"), time: 20000 });
      save_c.on("collect", async inter => {
        await inter.update({ content: `لقد قمت بحماية احدهم انتظر النتيجة`, components: [] }).catch(() => 0);
        let save_i = villagers.findIndex(p => p.id == inter.customId.split("_")[1]);
        if (save_i == villager_index) {
          return message.channel.send({ content: `❌ | **<@${data.players[player_index].id}>** تم حمايته من قبل الطبيب` });
        }
      });
      save_c.on("end", async end => {
        if (!has_play.get(message.guild.id)) return;
        data.players[player_index].type = "killed";
        await message.channel.send({ content: `🩸 | **<@${data.players[player_index].id}>** قتل بواسطة الذئاب` });
      });
    } else {
      data.players[player_index].type = "killed";
      await message.channel.send({ content: `🩸 | **<@${data.players[player_index].id}>** قتل بواسطة الذئاب` });
    }
    setTimeout(async () => await werewolf_game(message), 2000);
  });
}

function createMultipleButtons(buttons, type) {
  const button_rows = [];
  const buttonPerRow = 5;
  for (let i = 0; i < buttons.length; i += buttonPerRow) {
    let rows = new ActionRowBuilder();
    rows.addComponents(buttons.slice(i, i + buttonPerRow).map((button) => {
      return new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId(`${type}_${button.id}`)
        .setLabel(button.label)
        .setDisabled(button.disabled);
    }));
    button_rows.push(rows);
  }
  return button_rows;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = {
  mafia_command,
  werewolf_game
};
