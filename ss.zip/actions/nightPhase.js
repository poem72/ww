const werewolf_actions = require('./werewolfActions');
const doctor_actions = require('./doctorActions');
const seer_actions = require('./seerActions');
const check_win_conditions = require('./checkWinConditions');
const day_phase = require('./dayPhase');

async function night_phase(message, data) {
  message.channel.send("🌑 Night has fallen. Everyone, close your eyes...");

  // Werewolves choose a victim
  let victimId = await werewolf_actions(message, data);

  // Doctor chooses someone to protect
  let protectedId = await doctor_actions(message, data);

  // Seer reveals a player's role
  await seer_actions(message, data);

  // Process the night actions
  if (victimId && victimId !== protectedId) {
    let victim = data.players.find(p => p.id === victimId);
    message.channel.send(`💀 ${victim.username} was killed during the night!`);
    data.players = data.players.filter(p => p.id !== victimId);
  } else if (victimId && victimId === protectedId) {
    let victim = data.players.find(p => p.id === victimId);
    message.channel.send(`🛡️ ${victim.username} was attacked, but the Doctor saved them!`);
  }

  // Check for endgame conditions
  await check_win_conditions(message, data);

  // Start the day phase
  await day_phase(message, data);
}

module.exports = night_phase;
