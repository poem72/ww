class Doctor {
  constructor(player) {
    this.id = player.id;
    this.username = player.username;
    this.avatar = player.avatar;
    this.type = "doctor";
    this.interaction = player.interaction;
  }
}

module.exports = Doctor;
