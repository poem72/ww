class Villager {
  constructor(player) {
    this.id = player.id;
    this.username = player.username;
    this.avatar = player.avatar;
    this.type = "villager";
    this.interaction = player.interaction;
  }
}

module.exports = Villager;
