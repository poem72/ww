const { ButtonStyle, ButtonBuilder, EmbedBuilder, ActionRowBuilder, AttachmentBuilder } = require("discord.js");
const Villager = require('./roles/Villager');
const Werewolf = require('./roles/werewolf');
const Doctor = require('./roles/doctor');
const Seer = require('./roles/seer');

const has_play = new Map();

async function werewolf_command(message) {
  if (has_play.get(message.guild.id)) return message.reply({ content: `❌ There is already an active game in this server!` });

  let time = 20000;
  let data = {
    author: message.author.id,
    players: [],
    start_in: Date.now() + time,
    type: "werewolf"
  };

  const mention = '@everyone';
  const attachment = new AttachmentBuilder('./s2.png');

  const embed = new EmbedBuilder()
    .setColor("#1c2935")
    .setTitle("Werewolf")
    .setDescription(`__The game will start in__: **<t:${Math.floor(data.start_in / 1000)}:R>**`);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('join_werewolf')
        .setLabel('Join'),
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('leave_werewolf')
        .setLabel('Leave')
    );

  let msg = await message.channel.send({
    content: mention,
    files: [attachment],
    components: [row]
  });

  has_play.set(message.guild.id, data);

  let start_c = msg.createMessageComponentCollector({ time: time });

  start_c.on("collect", async inter => {
    if (inter.customId === "join_werewolf") {
      if (data.players.find(u => u.id == inter.user.id)) return inter.reply({ content: `You are already registered.`, ephemeral: true });
      if (data.players.length >= 20) return inter.reply({ content: `The participant limit is reached.`, ephemeral: true });

      let player = { id: inter.user.id, username: inter.user.username, avatar: inter.user.displayAvatarURL({ dynamic: true, format: "png" }), interaction: inter };
      data.players.push(new Villager(player));  // Default to Villager

      has_play.set(message.guild.id, data);
      embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__Participants:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
      msg.edit({ embeds: [embed] }).catch(() => 0);
      inter.reply({ content: `✅ You have been successfully added to the participants`, ephemeral: true });

    } else if (inter.customId == "leave_werewolf") {
      let index = data.players.findIndex(i => i.id == inter.user.id);
      if (index == -1) return inter.reply({ content: `❌ - You are not a participant`, ephemeral: true });

      data.players.splice(index, 1);
      has_play.set(message.guild.id, data);
      embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__Participants:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
      msg.edit({ embeds: [embed] }).catch(() => 0);
      inter.reply({ content: `✅ You have been removed from the participants`, ephemeral: true });
    }
  });

  start_c.on("end", async (end, reason) => {
    if (!has_play.get(message.guild.id)) return;

    embed.setDescription(`*(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`)
      .setColor("Red");
    msg.edit({ embeds: [embed], components: [] }).catch(() => 0);

    if (data.players.length < 5) {
      has_play.delete(message.guild.id);
      return message.channel.send({ content: `🚫 - The game was canceled due to insufficient players` });
    }

    // Assign roles
    let c = 5;
    for (let i = 0; i < data.players.length; i += c) {
      let array = data.players.slice(i, i + c);
      if (i == 0) {
        let werewolf = new Werewolf(array.splice(Math.floor(Math.random() * array.length), 1)[0]);
        let doctor = new Doctor(array.splice(Math.floor(Math.random() * array.length), 1)[0]);
        data.players[data.players.findIndex(m => m.id == werewolf.id)] = werewolf;
        data.players[data.players.findIndex(m => m.id == doctor.id)] = doctor;
      } else {
        if (array.length >= 5) {
          let werewolf = new Werewolf(array.splice(Math.floor(Math.random() * array.length), 1)[0]);
          data.players[data.players.findIndex(m => m.id == werewolf.id)] = werewolf;
        }
      }
    }

    has_play.set(message.guild.id, data);

    for (let player of data.players) {
      if (player.type === "villager") {
        await player.interaction.followUp({ content: `👥 | You are a **Villager**. During each round, you need to discuss with all players to identify the Werewolves and vote them out.`, ephemeral: true }).catch(() => 0);
      } else if (player.type === "doctor") {
        await player.interaction.followUp({ content: `🧑‍⚕️ | You are a **Doctor**. During each round, you can choose to protect one person from the Werewolves' attack.`, ephemeral: true }).catch(() => 0);
      } else if (player.type === "werewolf") {
        await player.interaction.followUp({ content: `🕵️ | You are a **Werewolf**. You must try to eliminate all other players without being detected.`, ephemeral: true }).catch(() => 0);
      } else if (player.type === "seer") {
        await player.interaction.followUp({ content: `🔮 | You are a **Seer**. You can choose to reveal the role of one player each night.`, ephemeral: true }).catch(() => 0);
      }
    }

    message.channel.send({
      content: `
✅ Roles have been assigned. The first round will start shortly...

__Team 1 (Villagers):__
**${data.players.filter(p => p.type == "doctor").length}** Doctor
**${data.players.filter(p => p.type == "villager").length}** Villager

__Team 2 (Werewolves):__
**${data.players.filter(p => p.type == "werewolf").length}** Werewolf
`
    });
  })
}
// Utility function for sleep
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Function to handle the werewolf's private voting phase
async function werewolf_vote(message, werewolves, players) {
  let rows = [];
  let row = new ActionRowBuilder();

  players.forEach((player, index) => {
    if (player.type !== "werewolf") {
      let button = new ButtonBuilder()
        .setCustomId(`kill_${player.id}`)
        .setLabel(player.username)
        .setStyle(ButtonStyle.Danger);

      row.addComponents(button);

      if ((index + 1) % 5 === 0) {
        rows.push(row);
        row = new ActionRowBuilder();
      }
    }
  });

  if (row.components.length > 0) rows.push(row);

  for (let werewolf of werewolves) {
    let voteMessage = await werewolf.interaction.user.send({
      content: "🌑 Werewolves, choose a victim:",
      components: rows
    });

    let collector = voteMessage.createMessageComponentCollector({ time: 30000 });

    let voteResult = new Promise(resolve => {
      collector.on('collect', async interaction => {
        if (!interaction.isButton()) return;

        let playerId = interaction.customId.split('_')[1];
        resolve(playerId);
        collector.stop();
      });

      collector.on('end', (collected, reason) => {
        if (reason === 'time') resolve(null);
      });
    });

    let votedId = await voteResult;

    if (votedId) {
      // Store the votes or handle them as needed
      werewolf.votes = votedId; // Assuming `votes` is where you store the choice
    }
  }
}

// Werewolf Actions
async function werewolf_actions(message, data) {
  let werewolves = data.players.filter(p => p.type === "werewolf");
  if (werewolves.length === 0) return;

  // Handle werewolf voting
  await werewolf_vote(message, werewolves, data.players);

  // Process the votes
  let votes = {};
  werewolves.forEach(w => {
    if (w.votes) {
      votes[w.votes] = (votes[w.votes] || 0) + 1;
    }
  });

  let maxVotes = Math.max(...Object.values(votes));
  let victimId = Object.keys(votes).find(id => votes[id] === maxVotes);

  if (victimId) {
    data.players = data.players.filter(p => p.id !== victimId);
    message.channel.send(`<@${victimId}> has been killed by the werewolves.`);
  }
}

// Doctor Actions
async function doctor_actions(message, data) {
  let doctor = data.players.find(p => p.type === "doctor");
  if (!doctor) return null;

  let rows = [];
  let row = new ActionRowBuilder();

  data.players.forEach((player, index) => {
    if (player.type !== "doctor") {
      let button = new ButtonBuilder()
        .setCustomId(`protect_${player.id}`)
        .setLabel(player.username)
        .setStyle(ButtonStyle.Success);

      row.addComponents(button);

      if ((index + 1) % 5 === 0) {
        rows.push(row);
        row = new ActionRowBuilder();
      }
    }
  });

  if (row.components.length > 0) rows.push(row);

  let protectMessage = await doctor.interaction.followUp({
    content: "🛡️ Choose a player to protect:",
    components: rows,
    ephemeral: true
  });

  let collector = protectMessage.createMessageComponentCollector({ time: 30000 });

  let protectResult = new Promise(resolve => {
    collector.on('collect', async interaction => {
      if (!interaction.isButton()) return;

      let playerId = interaction.customId.split('_')[1];
      resolve(playerId);
      collector.stop();
    });

    collector.on('end', (collected, reason) => {
      if (reason === 'time') resolve(null);
    });
  });

  return await protectResult;
}

// Seer Actions
async function seer_actions(message, data) {
  let seer = data.players.find(p => p.type === "seer");
  if (!seer) return null;

  let rows = [];
  let row = new ActionRowBuilder();

  data.players.forEach((player, index) => {
    if (player.id !== seer.id) {
      let button = new ButtonBuilder()
        .setCustomId(`reveal_${player.id}`)
        .setLabel(player.username)
        .setStyle(ButtonStyle.Secondary);

      row.addComponents(button);

      if ((index + 1) % 5 === 0) {
        rows.push(row);
        row = new ActionRowBuilder();
      }
    }
  });

  if (row.components.length > 0) rows.push(row);

  let revealMessage = await seer.interaction.followUp({
    content: "🔮 Choose a player to reveal their role:",
    components: rows,
    ephemeral: true
  });

  let collector = revealMessage.createMessageComponentCollector({ time: 30000 });

  let revealResult = new Promise(resolve => {
    collector.on('collect', async interaction => {
      if (!interaction.isButton()) return;

      let playerId = interaction.customId.split('_')[1];
      resolve(playerId);
      collector.stop();
    });

    collector.on('end', (collected, reason) => {
      if (reason === 'time') resolve(null);
    });
  });

  return await revealResult;
}

// Day Phase Function
async function day_phase(message, data) {
  message.channel.send("🌞 Day has arrived! Players, it's time to vote.");

  let rows = [];
  let row = new ActionRowBuilder();

  data.players.forEach((player, index) => {
    if (player.type !== "werewolf") {
      let button = new ButtonBuilder()
        .setCustomId(`vote_${player.id}`)
        .setLabel(player.username)
        .setStyle(ButtonStyle.Primary);

      row.addComponents(button);

      if ((index + 1) % 5 === 0) {
        rows.push(row);
        row = new ActionRowBuilder();
      }
    }
  });

  if (row.components.length > 0) rows.push(row);

  let voteMessage = await message.channel.send({
    content: "🗳️ Vote for the player you think is a Werewolf:",
    components: rows
  });

  let collector = voteMessage.createMessageComponentCollector({ time: 30000 });

  let votes = {};

  collector.on('collect', async interaction => {
    if (!interaction.isButton()) return;

    let playerId = interaction.customId.split('_')[1];
    votes[playerId] = (votes[playerId] || 0) + 1;
    await interaction.update({ content: `You voted for <@${playerId}>.`, components: [] });
  });

  collector.on('end', async () => {
    let maxVotes = Math.max(...Object.values(votes));
    let votedOutId = Object.keys(votes).find(id => votes[id] === maxVotes);

    if (votedOutId) {
      data.players = data.players.filter(p => p.id !== votedOutId);
      message.channel.send(`<@${votedOutId}> has been voted out.`);
    }

    // Check for end of game conditions
    await check_win_conditions(message, data);

    // Start the next night phase
    await night_phase(message, data);
  });
}

// Check Win Conditions
async function check_win_conditions(message, data) {
  let villagers = data.players.filter(p => p.type !== "werewolf");
  let werewolves = data.players.filter(p => p.type === "werewolf");

  if (werewolves.length === 0) {
    message.channel.send("🎉 Villagers have won!");
    has_play.delete(message.guild.id);
    return;
  }

  if (villagers.length === 0 || werewolves.length >= villagers.length) {
    message.channel.send("🎉 Werewolves have won!");
    has_play.delete(message.guild.id);
    return;
  }
}

module.exports = { werewolf_command };
