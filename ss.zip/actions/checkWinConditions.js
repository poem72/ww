async function checkWinConditions(message, data) {
    let villagers = data.players.filter(p => p.type !== "werewolf");
    let werewolves = data.players.filter(p => p.type === "werewolf");
  
    if (werewolves.length === 0) {
      message.channel.send("🎉 القرويون فازوا!");
      has_play.delete(message.guild.id);
      return;
    }
  
    if (villagers.length <= werewolves.length) {
      message.channel.send("🎉 الذئاب فازوا!");
      has_play.delete(message.guild.id);
      return;
    }
  
    await nightPhase(message, data);
  }
  
  module.exports = { checkWinConditions };
  