const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function doctor_actions(message, data) {
  let doctor = data.players.find(p => p.type === "doctor");
  if (!doctor) return;

  // Ask the Doctor to choose one player to protect
  let rows = [];
  let row = new ActionRowBuilder();

  data.players.forEach((player, index) => {
    if (player.id !== doctor.id) { // Doctor cannot protect themselves
      let button = new ButtonBuilder()
        .setCustomId(`protect_${player.id}`)
        .setLabel(player.username)
        .setStyle(ButtonStyle.Primary);

      row.addComponents(button);

      if ((index + 1) % 5 === 0) {
        rows.push(row);
        row = new ActionRowBuilder();
      }
    }
  });

  if (row.components.length > 0) rows.push(row);

  let protectMessage = await doctor.interaction.followUp({
    content: "👨‍⚕️ Choose someone to protect:",
    components: rows,
    ephemeral: true
  });

  let collector = protectMessage.createMessageComponentCollector({ time: 30000 });

  return new Promise(resolve => {
    collector.on('collect', async interaction => {
      if (!interaction.isButton()) return;

      let protectedPlayerId = interaction.customId.split('_')[1];
      let protectedPlayer = data.players.find(p => p.id === protectedPlayerId);

      await interaction.reply({ content: `You chose to protect ${protectedPlayer.username}.`, ephemeral: true });

      resolve(protectedPlayerId);
    });

    collector.on('end', async () => {
      if (collector.ended) {
        await doctor.interaction.followUp({ content: "You did not choose anyone to protect.", ephemeral: true });
        resolve(null);
      }
    });
  });
}

module.exports = doctor_actions;
