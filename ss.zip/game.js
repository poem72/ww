const { ButtonStyle, ButtonBuilder, EmbedBuilder, ActionRowBuilder } = require("discord.js");
const Villager = require('./roles/Villager');
const Werewolf = require('./roles/werewolf');
const Doctor = require('./roles/doctor');
const Seer = require('./roles/seer');

const has_play = new Map();

async function werewolf_command(message) {
  if (has_play.get(message.guild.id)) return message.reply({ content: `❌ هناك بالفعل لعبة فعالة في هذا السيرفر!` });

  let time = 20000;
  let data = {
    author: message.author.id,
    players: [],
    start_in: Date.now() + time,
    type: "werewolf"
  };

  const mention = '@everyone';
  const attachment = new AttachmentBuilder('./s2.png');

  const embed = new EmbedBuilder()
    .setColor("#1c2935")
    .setTitle("werewolf")
    .setDescription(`__ستبدأ اللعبة خلال__: **<t:${Math.floor(data.start_in / 1000)}:R>**`);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('join_werewolf')
        .setLabel('دخول'),
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('left_werewolf')
        .setLabel('خروج')
    );

  let msg = await message.channel.send({
    content: mention,
    files: [attachment],
    components: [row]
  });

  has_play.set(message.guild.id, data);

  let start_c = msg.createMessageComponentCollector({ time: time });

  start_c.on("collect", async inter => {
    if (inter.customId === "join_werewolf") {
      if (data.players.find(u => u.id == inter.user.id)) return inter.reply({ content: `لقد سجلت بالفعل.`, ephemeral: true });
      if (data.players.length >= 20) return inter.reply({ content: `عدد المشاركين مكتمل`, ephemeral: true });

      let player = { id: inter.user.id, username: inter.user.username, avatar: inter.user.displayAvatarURL({ dynamic: true, format: "png" }), interaction: inter };
      data.players.push(new Villager(player));  // Default to Villager

      has_play.set(message.guild.id, data);
      embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__اللاعبين المشاركين:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
      msg.edit({ embeds: [embed] }).catch(() => 0);
      inter.reply({ content: `✅ تم إضافتك للمشتركين بنجاح`, ephemeral: true });

    } else if (inter.customId == "left_werewolf") {
      let index = data.players.findIndex(i => i.id == inter.user.id);
      if (index == -1) return inter.reply({ content: `❌ - أنت غير مشارك بالفعل`, ephemeral: true });

      data.players.splice(index, 1);
      has_play.set(message.guild.id, data);
      embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__اللاعبين المشاركين:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
      msg.edit({ embeds: [embed] }).catch(() => 0);
      inter.reply({ content: `✅ تم إزالتك من المشتركين`, ephemeral: true });
    }
  });

  start_c.on("end", async (end, reason) => {
    if (!has_play.get(message.guild.id)) return;

    embed.setDescription(`*(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`)
      .setColor("Red");
    msg.edit({ embeds: [embed], components: [] }).catch(() => 0);

    if (data.players.length < 5) {
      has_play.delete(message.guild.id);
      return message.channel.send({ content: `🚫 - تم إلغاء اللعبة لعدم وجود 5 لاعبين على الأقل` });
    }

    // Assign roles
    let c = 5;
    for (let i = 0; i < data.players.length; i += c) {
      let array = data.players.slice(i, i + c);
      if (i == 0) {
        let werewolf = new Werewolf(array.splice(Math.floor(Math.random() * array.length), 1)[0]);
        let doctor = new Doctor(array.splice(Math.floor(Math.random() * array.length), 1)[0]);
        data.players[data.players.findIndex(m => m.id == werewolf.id)] = werewolf;
        data.players[data.players.findIndex(m => m.id == doctor.id)] = doctor;
      } else {
        if (array.length >= 5) {
          let werewolf = new Werewolf(array.splice(Math.floor(Math.random() * array.length), 1)[0]);
          data.players[data.players.findIndex(m => m.id == werewolf.id)] = werewolf;
        }
      }
    }

    has_play.set(message.guild.id, data);

    for (let player of data.players) {
      if (player.type === "villager") {
        await player.interaction.followUp({ content: `👥 | تم اختيارك كـ **قروي**. في كل جولة يجب عليك التحقق مع جميع اللاعبين لأكتشاف الذئاب وطردهم من اللعبة`, ephemeral: true }).catch(() => 0);
      } else if (player.type === "doctor") {
        await player.interaction.followUp({ content: `🧑‍⚕️ | تم اختيارك كـ **طبيب**. في كل جولة يمكنك حماية شخص واحد من هجوم الذئاب`, ephemeral: true }).catch(() => 0);
      } else if (player.type === "werewolf") {
        await player.interaction.followUp({ content: `🕵️ | تم اختيارك كـ **ذئب**. يجب عليكم محاولة اغتيال جميع اللاعبين بدون اكتشافكم`, ephemeral: true }).catch(() => 0);
      }
    }

    message.channel.send({
      content: `
✅ تم توزيع الرتب على اللاعبين. ستبدأ الجولة الأولى في بضع ثواني...

__الفريق الأول (القرويون):__
**${data.players.filter(p => p.type == "doctor").length}** طبيب
**${data.players.filter(p => p.type == "villager").length}** قروي

__الفريق الثاني (الذئاب):__
**${data.players.filter(p => p.type == "werewolf").length}** ذئب
`
    });

    await sleep(700);
    await werewolf_round(message);
  });
}

// Additional logic for gameplay would be added here

module.exports = { wereswolf_command };
